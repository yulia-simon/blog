export * from './updatePost.dto';
