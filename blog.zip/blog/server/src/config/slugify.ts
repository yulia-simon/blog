export default {
    replacement: '-',
    lower: true,
};
