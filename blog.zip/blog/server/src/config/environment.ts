export default {
    NODE_ENV: process.env.MODE,

};
