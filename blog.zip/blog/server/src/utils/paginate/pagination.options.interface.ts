export interface PaginationOptionsInterface {
    limit: number;
    page: number;
}
