export enum Sections {
    Technology = 'Technology',
    Design = 'Design',
    Culture = 'Culture',
    Business = 'Business',
    Politics = 'Politics',
    Opinion = 'Opinion',
    Science = 'Science',
    Health = 'Health',
    Style = 'Style',
    Travel = 'Travel',
}
