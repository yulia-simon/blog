

## Description

Frontend part of blog application where users can create and delete posts and comments. All data is fetched from backend.

## Installation

```bash
$ npm install
```

## Running the app

```bash
# development
$ npm run dev




