export interface MainProps {
    posts: ReadonlyArray<string>;
    title: string;
    comments: ReadonlyArray<string>;
    blog_id: string;
}
