
export interface FooterProps {
    description: string;
    title: string;
}
