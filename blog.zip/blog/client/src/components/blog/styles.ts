export const ToolbarStyles = { borderBottom: 1, borderColor: 'divider' };
export const ThemeHeaderNav = { justifyContent: 'space-between', overflowX: 'auto' };
export const AddPostButtonStyles = { minWidth: '2.5rem', minHeight: '2.5rem' }
